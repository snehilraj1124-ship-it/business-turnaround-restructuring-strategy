# Business Turnaround & Restructuring Strategy — NovaRetail

## Project Overview
A comprehensive turnaround case study for **NovaRetail**, a fictional Indian omnichannel retailer experiencing declining revenue, negative EBITDA, margin compression, excess inventory, high fixed costs and weak store productivity.

## Core Strategic Question
**How can an underperforming business restore cash generation and profitability without destroying the capabilities required for future growth?**

## Turnaround Philosophy
**Stabilize Cash → Fix Margin → Simplify Operations → Improve Productivity → Rebuild Growth**

## Key Analysis Areas
- Financial diagnosis
- Root cause analysis
- Store network rationalization
- Cost restructuring
- Inventory optimization
- Working capital management
- Pricing and margin recovery
- Procurement transformation
- Organization restructuring
- Digital/omnichannel turnaround
- Customer retention
- Turnaround initiative prioritization
- Cash stabilization
- Financial target setting
- Risk management
- Turnaround governance
- Scenario planning
- 12-month implementation roadmap
- KPI dashboard

## Main Turnaround Priorities

### Cash Stabilization
- Release excess inventory
- Improve receivables
- Optimize supplier terms
- Control discretionary spending
- Establish weekly cash governance

### Store Network Rationalization
- Identify structurally weak stores
- Close, relocate or renegotiate uneconomic locations
- Protect high-performing stores
- Improve store productivity

### Cost Restructuring
Focus on rent, payroll, marketing, logistics, technology and corporate overhead.

### Margin Recovery
- Reduce uncontrolled discounting
- Improve product mix
- Renegotiate procurement
- Introduce disciplined markdown rules
- Improve pricing architecture

### Inventory Optimization
- Segment inventory by velocity and margin
- Liquidate slow-moving SKUs
- Improve replenishment
- Reduce inventory days
- Release working capital

### Organizational Restructuring
- Simplify reporting layers
- Clarify accountability
- Protect critical talent
- Align headcount with the new operating model

## Financial Turnaround Model
The project includes a five-year illustrative financial baseline covering:
- Revenue
- Gross Margin
- Operating Costs
- EBITDA
- EBITDA Margin
- Inventory
- Receivables
- Payables
- Inventory Days
- Net Working Capital
- Store Count
- Employee Count

## Turnaround Initiative Framework
Initiatives are evaluated using EBITDA Impact, Cash Impact, Execution Risk, Time to Impact and Strategic Priority.

## Risk Management
The risk register covers execution disruption, employee attrition, customer churn, supplier resistance, brand damage from markdowns, liquidity shortfall and regulatory/compliance risk.

## 12-Month Roadmap
**Months 1–3:** cash stabilization, inventory reduction, store review and immediate cost controls.

**Months 4–6:** supplier renegotiation, organizational redesign, pricing reset and digital improvements.

**Months 7–9:** scale profitable stores/categories and rebuild customer retention.

**Months 10–12:** institutionalize the new operating model and prepare for controlled growth.

## Tools & Skills
- Microsoft Excel
- Data Analysis
- Financial Modeling
- Strategic Modeling
- Data Visualization
- Business Turnaround
- Corporate Restructuring
- Strategic Management
- Financial Analysis
- Cost Optimization
- Working Capital Management
- Profitability Analysis
- Risk Management
- Scenario Planning
- KPI Development
- Operational Strategy
- Change Management

## Repository Structure
```text
business-turnaround-restructuring-strategy/
├── README.md
├── PDF_Files/
├── Data/
└── Charts/
```

## Important Disclosure
**NovaRetail is a fictional company created specifically for this portfolio project.**

All financial figures, store metrics, employee numbers, cost savings, EBITDA impacts, targets, risk scores and operational assumptions are **synthetic/illustrative**.

They do not represent the actual financial performance, operations, employees or restructuring plans of any real company.

This project is intended for **portfolio, educational and demonstration purposes**.

## Suggested LinkedIn Description
Developed a business turnaround and restructuring strategy for a fictional Indian omnichannel retailer using a synthetic financial and operating model. Diagnosed revenue decline, margin compression, excess inventory, weak store economics and fixed-cost pressure. Built restructuring initiatives covering store rationalization, cost reduction, working capital release, pricing, procurement, organizational redesign and customer retention, supported by a 12-month turnaround roadmap, risk register and KPI dashboard.
